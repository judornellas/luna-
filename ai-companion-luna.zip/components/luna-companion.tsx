"use client"

import { useState, useRef, useCallback, useEffect } from "react"
import { Mic, MicOff, Moon, Volume2, VolumeX, Sparkles, Pause, Play, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface Message {
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

type Reminder = {
  id: string
  message: string
  triggerTime: Date
  timeoutId: NodeJS.Timeout
}

export default function LunaCompanion() {
  const [mounted, setMounted] = useState(false)
  const [isActive, setIsActive] = useState(false)
  const [isWaitingForWakeWord, setIsWaitingForWakeWord] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [lunaStatus, setLunaStatus] = useState<"idle" | "listening" | "thinking" | "speaking">("idle")
  const [currentMessage, setCurrentMessage] = useState("")
  const [liveTranscript, setLiveTranscript] = useState("")
  const [conversationHistory, setConversationHistory] = useState<Array<{ role: string; content: string }>>([])
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  const recognitionRef = useRef<any>(null)
  const isActiveRef = useRef(false)
  const isWaitingForWakeWordRef = useRef(false)
  const isSpeakingRef = useRef(false)
  const isProcessingRef = useRef(false)
  const pauseTimerRef = useRef<NodeJS.Timeout | null>(null)
  const proactiveTimerRef = useRef<NodeJS.Timeout | null>(null)
  const speechBufferRef = useRef("")
  const contextRef = useRef({
    currentActivity: "",
    interests: [] as string[],
    lastTopics: [] as string[],
  })
  const recognitionStateRef = useRef<"stopped" | "starting" | "running" | "stopping">("stopped")
  const restartTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const selectedVoiceRef = useRef<SpeechSynthesisVoice | null>(null)
  const isMutedRef = useRef(false)
  const isPausedRef = useRef(false)

  const [reminders, setReminders] = useState<Reminder[]>([])
  const taskCheckInTimerRef = useRef<NodeJS.Timeout | null>(null)
  const sessionStartTimeRef = useRef<Date>(new Date())

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    isActiveRef.current = isActive
  }, [isActive])

  useEffect(() => {
    isWaitingForWakeWordRef.current = isWaitingForWakeWord
  }, [isWaitingForWakeWord])

  useEffect(() => {
    isSpeakingRef.current = isSpeaking
  }, [isSpeaking])

  useEffect(() => {
    isMutedRef.current = isMuted
  }, [isMuted])

  useEffect(() => {
    isPausedRef.current = isPaused
  }, [isPaused])

  const safeStartRecognition = useCallback(() => {
    if (!recognitionRef.current) return

    if (recognitionStateRef.current !== "stopped") {
      console.log("[v0] Cannot start - state is:", recognitionStateRef.current)
      return
    }

    try {
      recognitionStateRef.current = "starting"
      recognitionRef.current.start()
      console.log("[v0] Recognition start called")
    } catch (e: any) {
      console.log("[v0] Start failed:", e.message)
      recognitionStateRef.current = "stopped"
    }
  }, [])

  const safeStopRecognition = useCallback(() => {
    if (!recognitionRef.current) return

    // Clear any pending restart
    if (restartTimeoutRef.current) {
      clearTimeout(restartTimeoutRef.current)
      restartTimeoutRef.current = null
    }

    if (recognitionStateRef.current === "stopped" || recognitionStateRef.current === "stopping") {
      return
    }

    try {
      recognitionStateRef.current = "stopping"
      recognitionRef.current.stop()
      console.log("[v0] Recognition stop called")
    } catch (e) {
      recognitionStateRef.current = "stopped"
    }
  }, [])

  const scheduleRestart = useCallback(
    (delay = 500) => {
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current)
      }

      restartTimeoutRef.current = setTimeout(() => {
        restartTimeoutRef.current = null

        if (!isActiveRef.current && !isWaitingForWakeWordRef.current) {
          return
        }

        if (isSpeakingRef.current) {
          return
        }

        safeStartRecognition()
      }, delay)
    },
    [safeStartRecognition],
  )

  const parseTimeRequest = useCallback(
    (message: string): { type: string; minutes?: number; reminder?: string } | null => {
      const lowerMessage = message.toLowerCase()

      // "tell me when X minutes/hours has gone by" or "let me know in X minutes"
      const timePassedMatch = lowerMessage.match(
        /(?:tell me|let me know|notify me).*?(\d+)\s*(minute|min|hour|hr|second|sec)s?.*(?:has|have)?\s*(?:gone|passed|by)?/i,
      )
      if (timePassedMatch) {
        let minutes = Number.parseInt(timePassedMatch[1])
        const unit = timePassedMatch[2].toLowerCase()
        if (unit.startsWith("hour") || unit === "hr") minutes *= 60
        if (unit.startsWith("sec")) minutes = Math.max(1, Math.floor(minutes / 60))
        return { type: "timer", minutes }
      }

      // "remind me in X minutes" pattern
      const remindInMatch = lowerMessage.match(
        /remind\s*(?:me)?\s*(?:in|after)\s*(\d+)\s*(minute|min|hour|hr|second|sec)s?(?:\s*(?:to|about|of)\s*(.+))?/i,
      )
      if (remindInMatch) {
        let minutes = Number.parseInt(remindInMatch[1])
        const unit = remindInMatch[2].toLowerCase()
        if (unit.startsWith("hour") || unit === "hr") minutes *= 60
        if (unit.startsWith("sec")) minutes = Math.max(1, Math.floor(minutes / 60))
        const reminder = remindInMatch[3]?.trim() || "your reminder"
        return { type: "reminder", minutes, reminder }
      }

      // "remind me later to..." pattern
      const remindLaterMatch = lowerMessage.match(/remind\s*(?:me)?\s*later\s*(?:to|about|of)?\s*(.+)/i)
      if (remindLaterMatch) {
        const reminder = remindLaterMatch[1]?.trim() || "your reminder"
        return { type: "reminder", minutes: 30, reminder } // default 30 min for "later"
      }

      // "set a timer for X minutes"
      const timerMatch = lowerMessage.match(
        /(?:set|start)\s*(?:a)?\s*timer\s*(?:for)?\s*(\d+)\s*(minute|min|hour|hr|second|sec)s?/i,
      )
      if (timerMatch) {
        let minutes = Number.parseInt(timerMatch[1])
        const unit = timerMatch[2].toLowerCase()
        if (unit.startsWith("hour") || unit === "hr") minutes *= 60
        if (unit.startsWith("sec")) minutes = Math.max(1, Math.floor(minutes / 60))
        return { type: "timer", minutes }
      }

      return null
    },
    [],
  )

  const setReminder = useCallback((minutes: number, reminderMessage: string, isTimer = false) => {
    const id = Date.now().toString()
    const triggerTime = new Date(Date.now() + minutes * 60 * 1000)

    const timeoutId = setTimeout(
      () => {
        const message = isTimer
          ? `Hey! ${minutes} minute${minutes !== 1 ? "s" : ""} ${minutes !== 1 ? "have" : "has"} passed!`
          : `Hey! Just a reminder: ${reminderMessage}`

        speakMessage(message)
        setConversationHistory((prev) => [
          ...prev,
          {
            role: "assistant",
            content: message,
            timestamp: new Date(),
          },
        ])

        // Remove from active reminders
        setReminders((prev) => prev.filter((r) => r.id !== id))
      },
      minutes * 60 * 1000,
    )

    const newReminder: Reminder = {
      id,
      message: isTimer ? `Timer for ${minutes} min` : reminderMessage,
      triggerTime,
      timeoutId,
    }

    setReminders((prev) => [...prev, newReminder])

    return newReminder
  }, [])

  const scheduleTaskCheckIn = useCallback(() => {
    if (taskCheckInTimerRef.current) {
      clearTimeout(taskCheckInTimerRef.current)
    }

    // Random interval between 15 and 45 minutes (in ms)
    const delay = Math.floor(Math.random() * (45 - 15 + 1) + 15) * 60 * 1000

    taskCheckInTimerRef.current = setTimeout(async () => {
      if (!isActiveRef.current || isSpeakingRef.current || isProcessingRef.current || isPausedRef.current) {
        scheduleTaskCheckIn()
        return
      }

      const activity = contextRef.current.currentActivity
      const checkInMessages = activity
        ? [
            `Hey, how's the ${activity} going?`,
            `Still working on ${activity}? How's it coming along?`,
            `How are you doing with ${activity}?`,
            `Making progress with ${activity}?`,
            `Everything going okay with ${activity}?`,
          ]
        : [
            `Hey, what are you up to now?`,
            `Just checking in! How's it going?`,
            `What are you working on?`,
            `How are things going over there?`,
          ]

      const message = checkInMessages[Math.floor(Math.random() * checkInMessages.length)]

      setConversationHistory((prev) => [
        ...prev,
        {
          role: "assistant",
          content: message,
          timestamp: new Date(),
        },
      ])
      speakMessage(message)

      // Schedule next check-in
      scheduleTaskCheckIn()
    }, delay)
  }, [])

  const sendToLuna = useCallback(
    async (text: string) => {
      console.log("[v0] sendToLuna called with:", text)

      if (!isActiveRef.current) {
        console.log("[v0] Not active, ignoring")
        return
      }

      if (isProcessingRef.current || isPausedRef.current) {
        console.log("[v0] Already processing or paused, ignoring")
        return
      }

      isProcessingRef.current = true
      setIsProcessing(true)

      // Check for time/reminder requests first
      const timeRequest = parseTimeRequest(text)
      if (timeRequest) {
        let response = ""
        if (timeRequest.type === "timer" && timeRequest.minutes) {
          setReminder(timeRequest.minutes, "", true)
          response = `Got it! I'll let you know when ${timeRequest.minutes} minute${timeRequest.minutes !== 1 ? "s" : ""} ${timeRequest.minutes !== 1 ? "have" : "has"} passed.`
        } else if (timeRequest.type === "reminder" && timeRequest.minutes && timeRequest.reminder) {
          setReminder(timeRequest.minutes, timeRequest.reminder, false)
          response = `Okay! I'll remind you ${timeRequest.minutes === 30 ? "later" : `in ${timeRequest.minutes} minute${timeRequest.minutes !== 1 ? "s" : ""}`} about: ${timeRequest.reminder}`
        }

        if (response) {
          const userMessage: Message = { role: "user", content: text, timestamp: new Date() }
          const assistantMessage: Message = { role: "assistant", content: response, timestamp: new Date() }
          setConversationHistory((prev) => [...prev, userMessage, assistantMessage])
          speakMessage(response)
          isProcessingRef.current = false
          setIsProcessing(false)
          return
        }
      }

      const userMessage: Message = { role: "user", content: text, timestamp: new Date() }
      setConversationHistory((prev) => [...prev, userMessage])

      const lowerText = text.toLowerCase()
      if (lowerText.includes("cooking") || lowerText.includes("making")) {
        contextRef.current.currentActivity = "cooking"
      } else if (lowerText.includes("cleaning") || lowerText.includes("tidying")) {
        contextRef.current.currentActivity = "cleaning"
      } else if (lowerText.includes("working") || lowerText.includes("studying")) {
        contextRef.current.currentActivity = "working"
      } else if (lowerText.includes("watching") || lowerText.includes("series") || lowerText.includes("show")) {
        contextRef.current.currentActivity = "watching"
      }

      try {
        console.log("[v0] Fetching AI response...")
        const response = await fetch("/api/luna-chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: text,
            context: contextRef.current,
            conversationHistory: conversationHistory.slice(-6),
          }),
        })

        const responseText = await response.text()
        let data
        try {
          data = JSON.parse(responseText)
        } catch (parseError) {
          console.error("[v0] Failed to parse response:", responseText)
          throw new Error("Invalid response from server")
        }

        const lunaResponse = data.response || "I'm here! What were you saying?"
        console.log("[v0] Got response:", lunaResponse)

        const assistantMessage: Message = { role: "assistant", content: lunaResponse, timestamp: new Date() }
        setConversationHistory((prev) => [...prev, assistantMessage])

        speakMessage(lunaResponse)
      } catch (error) {
        console.error("[v0] Error getting AI response:", error)
        isProcessingRef.current = false
        setLunaStatus("listening")
        speakMessage("Sorry, I had a little hiccup there. What were you saying?")
      }
    },
    [conversationHistory, parseTimeRequest, setReminder],
  )

  const speakMessage = useCallback(
    (text: string) => {
      if (isMuted) {
        console.log("[v0] Muted, not speaking")
        isProcessingRef.current = false
        scheduleRestart(300)
        return
      }

      console.log("[v0] Speaking:", text.substring(0, 50) + "...")

      // Stop listening while speaking
      safeStopRecognition()

      setIsActive(true)
      setLunaStatus("speaking")
      window.speechSynthesis.cancel()

      setTimeout(() => {
        const voices = window.speechSynthesis.getVoices()
        const utterance = new SpeechSynthesisUtterance(text)

        const preferredVoice = voices.find(
          (voice) =>
            voice.name.includes("Samantha") ||
            voice.name.includes("Karen") ||
            voice.name.includes("Google US English") ||
            voice.name.includes("Microsoft Zira") ||
            (voice.lang === "en-US" && voice.localService),
        )
        if (preferredVoice) {
          utterance.voice = preferredVoice
        }

        utterance.rate = 1.1
        utterance.pitch = 1.05
        utterance.volume = 1.0

        utterance.onend = () => {
          console.log("[v0] Finished speaking")
          setIsActive(false)
          setLunaStatus("listening")
          isProcessingRef.current = false
          setIsSpeaking(false)

          if (isActiveRef.current) {
            scheduleRestart(500)
          }
        }

        utterance.onerror = (e) => {
          console.log("[v0] Speech error (non-critical)")
          setIsActive(false)
          setLunaStatus("listening")
          isProcessingRef.current = false
          setIsSpeaking(false)

          if (isActiveRef.current) {
            scheduleRestart(500)
          }
        }

        window.speechSynthesis.speak(utterance)
      }, 150)
    },
    [safeStopRecognition, scheduleRestart],
  )

  const scheduleProactiveMessage = useCallback(() => {
    if (proactiveTimerRef.current) {
      clearTimeout(proactiveTimerRef.current)
    }

    const delay = Math.floor(Math.random() * (45000 - 15000 + 1)) + 15000

    proactiveTimerRef.current = setTimeout(async () => {
      if (!isActiveRef.current || isSpeakingRef.current || isProcessingRef.current || isPausedRef.current) {
        scheduleProactiveMessage()
        return
      }
      try {
        const response = await fetch("/api/luna-proactive", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            context: contextRef.current,
            conversationHistory: [],
          }),
        })

        const responseText = await response.text()
        let data
        try {
          data = JSON.parse(responseText)
        } catch (parseError) {
          console.error("[v0] Failed to parse proactive response:", responseText)
          return
        }

        if (data.message) {
          const assistantMessage: Message = {
            role: "assistant",
            content: data.message,
            timestamp: new Date(),
          }
          setConversationHistory((prev) => [...prev, assistantMessage])
          speakMessage(data.message)
        }
      } catch (error) {
        console.error("[v0] Proactive message error:", error)
      }
    }, delay)
  }, [])

  const togglePause = useCallback(() => {
    const newPaused = !isPaused
    setIsPaused(newPaused)
    isPausedRef.current = newPaused

    if (newPaused) {
      // Pause: stop listening and cancel any pending proactive messages
      safeStopRecognition()
      if (proactiveTimerRef.current) {
        clearTimeout(proactiveTimerRef.current)
        proactiveTimerRef.current = null
      }
      if (pauseTimerRef.current) {
        clearTimeout(pauseTimerRef.current)
        pauseTimerRef.current = null
      }
      window.speechSynthesis?.cancel()
    } else {
      // Resume: start listening again and schedule proactive message
      safeStartRecognition()
      scheduleProactiveMessage()
    }
  }, [safeStartRecognition, safeStopRecognition])

  const activateLuna = useCallback(() => {
    console.log("[v0] Activating Luna!")
    setIsActive(true)
    setIsWaitingForWakeWord(false)
    speechBufferRef.current = ""
    setLiveTranscript("")
    setIsSpeaking(false)

    const welcomeMessage = "Hi! I'm Luna! I'm so happy you're here. What are you up to today?"
    setConversationHistory([{ role: "assistant", content: welcomeMessage, timestamp: new Date() }])

    setTimeout(() => {
      speakMessage(welcomeMessage)
      scheduleProactiveMessage()
    }, 500)
  }, [speakMessage])

  const stopLuna = useCallback(() => {
    setIsActive(false)
    setIsWaitingForWakeWord(false)
    setLunaStatus("idle")
    window.speechSynthesis.cancel()
    safeStopRecognition()
    if (proactiveTimerRef.current) {
      clearTimeout(proactiveTimerRef.current)
    }
    if (pauseTimerRef.current) {
      clearTimeout(pauseTimerRef.current)
    }
    setIsSpeaking(false)
    setIsPaused(false)
  }, [safeStopRecognition])

  const toggleMute = useCallback(() => {
    setIsMuted(!isMuted)
    if (!isMuted) {
      window.speechSynthesis.cancel()
      setIsActive(false)
    }
  }, [])

  useEffect(() => {
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition
    if (!SpeechRecognition) {
      alert("Sorry, your browser doesn't support speech recognition. Please use Chrome.")
      return
    }

    window.speechSynthesis.getVoices()

    const recognition = new SpeechRecognition()
    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = "en-US"
    recognitionRef.current = recognition

    recognition.onstart = () => {
      console.log("[v0] Recognition started (onstart)")
      recognitionStateRef.current = "running"
      setIsListening(true)
      if (isActiveRef.current) {
        setLunaStatus("listening")
      }
    }

    recognition.onresult = (event: any) => {
      if (isSpeakingRef.current || isProcessingRef.current || isPausedRef.current) {
        return
      }

      let finalTranscript = ""
      let interimTranscript = ""

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i]
        if (result.isFinal) {
          finalTranscript += result[0].transcript
        } else {
          interimTranscript += result[0].transcript
        }
      }

      const heardText = (finalTranscript + interimTranscript).trim()
      console.log("[v0] Heard:", heardText)

      // Check for wake word
      if (isWaitingForWakeWordRef.current && !isActiveRef.current) {
        const lower = heardText.toLowerCase()
        if (lower.includes("hi luna") || lower.includes("hey luna") || lower.includes("hello luna")) {
          console.log("[v0] Wake word detected!")
          activateLuna()
          return
        }
      }

      if (isActiveRef.current) {
        setLiveTranscript(heardText)

        if (finalTranscript.trim()) {
          speechBufferRef.current += (speechBufferRef.current ? " " : "") + finalTranscript.trim()
          console.log("[v0] Buffer:", speechBufferRef.current)
        }

        if (pauseTimerRef.current) {
          clearTimeout(pauseTimerRef.current)
          pauseTimerRef.current = null
        }

        if (speechBufferRef.current.trim()) {
          pauseTimerRef.current = setTimeout(() => {
            const textToSend = speechBufferRef.current.trim()
            console.log("[v0] Pause timeout - sending:", textToSend)

            if (textToSend && !isProcessingRef.current && !isSpeakingRef.current && !isPausedRef.current) {
              speechBufferRef.current = ""
              setLiveTranscript("")
              sendToLuna(textToSend)
            }
          }, 800)
        }
      }
    }

    recognition.onerror = (event: any) => {
      console.log("[v0] Recognition error:", event.error)

      recognitionStateRef.current = "stopped"
      setIsListening(false)

      // Ignore aborted errors - they're expected when we stop manually
      if (event.error === "aborted" || event.error === "no-speech") {
        // Schedule restart if we should still be listening
        if (
          (isActiveRef.current || isWaitingForWakeWordRef.current) &&
          !isSpeakingRef.current &&
          !isPausedRef.current
        ) {
          scheduleRestart(1000)
        }
        return
      }

      if (event.error === "not-allowed" || event.error === "audio-capture") {
        alert("Luna needs microphone access. Please allow it in your browser settings.")
        return
      }

      // Restart on other errors
      if ((isActiveRef.current || isWaitingForWakeWordRef.current) && !isSpeakingRef.current && !isPausedRef.current) {
        scheduleRestart(1000)
      }
    }

    recognition.onend = () => {
      console.log("[v0] Recognition ended (onend)")
      recognitionStateRef.current = "stopped"
      setIsListening(false)

      if (
        (isActiveRef.current || isWaitingForWakeWordRef.current) &&
        !isSpeakingRef.current &&
        !restartTimeoutRef.current &&
        !isPausedRef.current
      ) {
        scheduleRestart(500)
      }
    }

    return () => {
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current)
      }
      try {
        recognition.stop()
      } catch (e) {}
      recognitionStateRef.current = "stopped"
      window.speechSynthesis.cancel()
      if (pauseTimerRef.current) clearTimeout(pauseTimerRef.current)
      if (proactiveTimerRef.current) clearTimeout(proactiveTimerRef.current)
    }
  }, [sendToLuna, scheduleRestart])

  useEffect(() => {
    if (!recognitionRef.current) return

    const shouldListen = (isActive || isWaitingForWakeWord) && !isSpeakingRef.current && !isPausedRef.current

    if (shouldListen) {
      scheduleRestart(100)
    } else if (!isActiveRef.current && !isWaitingForWakeWordRef.current) {
      safeStopRecognition()
    }
  }, [isActive, isWaitingForWakeWord, isSpeakingRef.current, isPausedRef.current, scheduleRestart, safeStopRecognition])

  useEffect(() => {
    if (isActive && !isPaused) {
      sessionStartTimeRef.current = new Date()
      scheduleTaskCheckIn()
    }

    return () => {
      if (taskCheckInTimerRef.current) {
        clearTimeout(taskCheckInTimerRef.current)
      }
    }
  }, [isActive, isPaused, scheduleTaskCheckIn])

  useEffect(() => {
    return () => {
      reminders.forEach((r) => clearTimeout(r.timeoutId))
    }
  }, [reminders])

  if (!mounted) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-card rounded-3xl shadow-2xl p-8 border border-border">
            <div className="flex flex-col items-center space-y-6">
              <div className="relative">
                <div className="w-32 h-32 rounded-full bg-primary/20 flex items-center justify-center">
                  <Moon className="w-16 h-16 text-primary" />
                </div>
              </div>
              <h1 className="text-2xl font-bold text-foreground">Luna</h1>
              <p className="text-muted-foreground text-center">Loading...</p>
            </div>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl p-6 md:p-8 space-y-6 shadow-2xl">
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2">
            <Sparkles className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold text-balance bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Luna
            </h1>
          </div>
          <p className="text-muted-foreground text-pretty">Your supportive companion for everyday tasks</p>
        </div>

        <div className="relative">
          <div
            className={cn(
              "flex items-center justify-center h-48 rounded-3xl transition-all duration-500",
              (isActive || isWaitingForWakeWord) && lunaStatus === "listening" && "bg-primary/10 animate-pulse",
              isActive && lunaStatus === "speaking" && "bg-secondary/20",
              isActive && lunaStatus === "thinking" && "bg-accent/10",
              !isActive && !isWaitingForWakeWord && "bg-muted/30",
            )}
          >
            <div
              className={cn(
                "relative w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300",
                (isActive || isWaitingForWakeWord) && "scale-110",
              )}
            >
              {(isActive || isWaitingForWakeWord) && (
                <>
                  <div className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
                  <div className="absolute inset-2 rounded-full bg-secondary/20 animate-ping animation-delay-150" />
                </>
              )}
              <div
                className={cn(
                  "relative z-10 w-20 h-20 rounded-full flex items-center justify-center text-4xl transition-all duration-300",
                  isActive || isWaitingForWakeWord ? "bg-gradient-to-br from-primary to-secondary" : "bg-muted",
                )}
              >
                {lunaStatus === "speaking" ? "💬" : lunaStatus === "thinking" ? "🤔" : "🌙"}
              </div>
            </div>
          </div>

          <div className="mt-4 text-center space-y-2">
            <p
              className={cn(
                "text-lg font-medium transition-colors",
                isActive || isWaitingForWakeWord ? "text-foreground" : "text-muted-foreground",
              )}
            >
              {!isActive && !isWaitingForWakeWord && "Ready to start"}
              {isWaitingForWakeWord && "Say 'Hi Luna' or click Start Luna"}
              {isActive && lunaStatus === "listening" && "I'm listening..."}
              {isActive && lunaStatus === "speaking" && "Speaking..."}
              {isActive && lunaStatus === "thinking" && "Thinking..."}
            </p>

            {liveTranscript && (
              <div className="mt-2 p-3 bg-primary/10 border border-primary/30 rounded-2xl">
                <p className="text-xs text-muted-foreground mb-1">I hear you:</p>
                <p className="text-sm text-foreground font-medium">"{liveTranscript}"</p>
              </div>
            )}

            {(isActive || isWaitingForWakeWord) && (
              <div className="flex items-center justify-center gap-2 mt-3">
                <div
                  className={cn("w-3 h-3 rounded-full", isListening ? "bg-green-500 animate-pulse" : "bg-red-500")}
                />
                <p className="text-xs text-muted-foreground">{isListening ? "Microphone active" : "Microphone off"}</p>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center justify-center gap-4 flex-wrap">
          {!isActive && !isWaitingForWakeWord && (
            <>
              <Button size="lg" variant="default" onClick={activateLuna} className="min-w-[140px] h-12 text-base">
                <Mic className="mr-2 h-5 w-5" />
                Start Luna
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => setIsWaitingForWakeWord(true)}
                className="min-w-[180px] h-12 text-base bg-transparent"
              >
                <Sparkles className="mr-2 h-5 w-5" />
                Wait for "Hi Luna"
              </Button>
            </>
          )}

          {isWaitingForWakeWord && !isActive && (
            <>
              <Button size="lg" variant="default" onClick={activateLuna} className="min-w-[140px] h-12 text-base">
                <Mic className="mr-2 h-5 w-5" />
                Start Now
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => setIsWaitingForWakeWord(false)}
                className="min-w-[120px] h-12 text-base bg-transparent"
              >
                Cancel
              </Button>
            </>
          )}

          {isActive && (
            <>
              <Button size="lg" variant="destructive" onClick={stopLuna} className="min-w-[140px] h-12 text-base">
                <MicOff className="mr-2 h-5 w-5" />
                Stop Luna
              </Button>
              <Button
                size="lg"
                variant={isPaused ? "default" : "secondary"}
                onClick={togglePause}
                className="min-w-[120px] h-12 text-base"
              >
                {isPaused ? <Play className="mr-2 h-5 w-5" /> : <Pause className="mr-2 h-5 w-5" />}
                {isPaused ? "Resume" : "Pause"}
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={toggleMute}
                className="min-w-[120px] h-12 text-base bg-transparent"
              >
                {isMuted ? <VolumeX className="mr-2 h-5 w-5" /> : <Volume2 className="mr-2 h-5 w-5" />}
                {isMuted ? "Unmute" : "Mute"}
              </Button>
            </>
          )}
        </div>

        {conversationHistory.length > 0 && (
          <div className="max-h-64 overflow-y-auto space-y-3 p-4 bg-muted/20 rounded-2xl">
            {conversationHistory.slice(-10).map((msg, i) => (
              <div
                key={i}
                className={cn(
                  "p-3 rounded-2xl max-w-[85%]",
                  msg.role === "assistant" ? "bg-secondary/20 mr-auto" : "bg-primary/20 ml-auto",
                )}
              >
                <p className="text-xs text-muted-foreground mb-1">{msg.role === "assistant" ? "Luna" : "You"}</p>
                <p className="text-sm">{msg.content}</p>
              </div>
            ))}
          </div>
        )}

        {reminders.length > 0 && (
          <div className="mt-4 w-full max-w-md">
            <div className="bg-card/50 rounded-lg p-3 border border-border/50">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                <Clock className="w-4 h-4" />
                <span>Active Reminders</span>
              </div>
              <div className="space-y-1">
                {reminders.map((r) => (
                  <div key={r.id} className="text-sm text-foreground/80">
                    {r.message} - {r.triggerTime.toLocaleTimeString()}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </Card>
    </main>
  )
}
