export const maxDuration = 30

const proactivePrompts = [
  "Generate a casual, friendly check-in question based on their current activity",
  "Ask about something they mentioned earlier in the conversation",
  "Share an interesting random thought or fact, then ask their opinion",
  "Ask about their day or how they're feeling",
  "If they mentioned an interest, ask about it naturally",
  "Ask a light, engaging question about their preferences (favorite movie, book, food, etc.)",
]

const fallbacks = [
  "Hey, how's it going over there?",
  "What are you up to?",
  "Everything okay?",
  "How's your day been?",
  "Still there? Just checking in!",
  "What's on your mind?",
]

export async function POST(req: Request) {
  console.log("[v0] Proactive - OPENAI_API_KEY present:", !!process.env.OPENAI_API_KEY)

  let requestBody
  try {
    requestBody = await req.json()
  } catch (e) {
    return Response.json({
      message: fallbacks[Math.floor(Math.random() * fallbacks.length)],
    })
  }

  const { context, conversationHistory } = requestBody

  const randomPromptType = proactivePrompts[Math.floor(Math.random() * proactivePrompts.length)]

  const systemPrompt = `You are Luna, a warm and friendly AI companion. You're initiating a conversation naturally, like a friend would when hanging out together during a task.

Current context:
${context?.currentActivity ? `They are currently: ${context.currentActivity}` : "Unknown activity"}
${context?.interests?.length > 0 ? `Their interests: ${context.interests.join(", ")}` : ""}

Task: ${randomPromptType}

Guidelines:
- Keep it SHORT (1-2 sentences max)
- Be natural and conversational
- Don't be repetitive - vary your approach
- For activity check-ins, reference what they're doing specifically:
  - Cooking: "How's the cooking going? Does it smell amazing yet?"
  - Cleaning: "Making progress? I hope it's not too tedious!"
  - Watching: "What are you watching? Any good?"
- For random thoughts: Keep it light and interesting
- For questions: Make them engaging but not intrusive
- Sound like a real person, not a chatbot

Generate one natural, proactive message from Luna:`

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...(conversationHistory || []).slice(-4).map((msg: any) => ({
            role: msg.role,
            content: msg.content,
          })),
          {
            role: "user",
            content: "Generate a proactive message to keep the conversation going naturally.",
          },
        ],
        max_tokens: 100,
        temperature: 0.9,
      }),
    })

    const responseText = await response.text()
    console.log("[v0] Proactive OpenAI response status:", response.status)

    if (!response.ok) {
      console.error("[v0] Proactive OpenAI error:", responseText)
      return Response.json({
        message: fallbacks[Math.floor(Math.random() * fallbacks.length)],
      })
    }

    const data = JSON.parse(responseText)
    const text = data.choices?.[0]?.message?.content || fallbacks[Math.floor(Math.random() * fallbacks.length)]

    return Response.json({ message: text })
  } catch (error: any) {
    console.error("[v0] Luna proactive error:", error?.message)
    return Response.json({
      message: fallbacks[Math.floor(Math.random() * fallbacks.length)],
    })
  }
}
