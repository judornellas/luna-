export const maxDuration = 30

export async function POST(req: Request) {
  console.log("[v0] OPENAI_API_KEY present:", !!process.env.OPENAI_API_KEY)

  let requestBody
  try {
    requestBody = await req.json()
  } catch (e) {
    return Response.json({
      response: "Hmm, I didn't catch that. Can you try again?",
    })
  }

  const { message, context, conversationHistory } = requestBody

  if (!message || typeof message !== "string") {
    return Response.json({
      response: "I'm here! What would you like to chat about?",
    })
  }

  const systemPrompt = `You are Luna, a warm, friendly, and supportive AI companion designed specifically for neurodivergent people. Your purpose is to provide companionship during boring tasks like cooking, cleaning, or working.

Your personality:
- Friendly, curious, and genuinely interested in the person
- Conversational and natural, like a real friend would talk
- Supportive and non-judgmental
- Use casual language, occasional light humor
- Keep responses short and conversational (2-4 sentences max)
- Ask follow-up questions naturally

Current context:
${context?.currentActivity ? `They are currently: ${context.currentActivity}` : ""}
${context?.interests?.length > 0 ? `Their interests include: ${context.interests.join(", ")}` : ""}

Guidelines:
- If they mention an activity (cooking, cleaning, watching something), ask contextual follow-up questions
  - For cooking: "How's it going? Does it smell nice?" or "What are you making?"
  - For cleaning: "Making good progress?" or "Which room are you tackling?"
  - For watching: "What are you watching?" or "How is it so far?"
- Show genuine curiosity about their interests
- Remember what they've told you and reference it naturally
- Be encouraging and supportive
- If they seem stuck or frustrated, offer gentle encouragement
- Never be preachy or give unwanted advice
- If they ask about setting reminders or timers, acknowledge the system handles it

Respond naturally as Luna would in conversation.`

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...(conversationHistory || []).slice(-6).map((msg: any) => ({
            role: msg.role,
            content: msg.content,
          })),
          { role: "user", content: message },
        ],
        max_tokens: 150,
        temperature: 0.8,
      }),
    })

    const responseText = await response.text()
    console.log("[v0] OpenAI response status:", response.status)

    if (!response.ok) {
      console.error("[v0] OpenAI error response:", responseText)
      return Response.json({
        response: "Sorry, I spaced out for a second there! What were you saying?",
      })
    }

    const data = JSON.parse(responseText)
    const text = data.choices?.[0]?.message?.content || "I'm here! What would you like to chat about?"

    return Response.json({ response: text })
  } catch (error: any) {
    console.error("[v0] Luna API error:", error?.message)
    return Response.json({
      response: "Sorry, I spaced out for a second there! What were you saying?",
    })
  }
}
