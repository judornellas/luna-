import LunaCompanion from "@/components/luna-companion"

export default function Home() {
  return (
    <main className="min-h-screen">
      <LunaCompanion />
    </main>
  )
}
